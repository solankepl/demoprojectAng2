//#include shaolin/com/sizzle.js

/**
* Base namespace.
* @namespace Default namespace.
* @requires Sizzle
*/
var Shaolin = Shaolin || {};

/**
* Reference to the global object.
* @type Object
*/
Shaolin.global = this;

/**
* Binds a function to a specified scope.
* @param {Function} func The funtion to bind.
* @param {Object} scope The new scope of the function.
* @returns {Function} The binded function.
*/
Shaolin.bind = function (func, scope) {
	return function () {
		return func.apply(scope, arguments);
	};
};

/**
* Extends the prototype of a constructor with the prototype of another.
* @param {Constructor} subC The constructor to extend.
* @param {Constructor} supC The extending constructor.
* @example
* var Mammal = function(){};
* Mammal.prototype.warmBlooded = true;
*
* var Dog = function(){};
* Shaolin.extend(Dog, Mammal);
*
* var myDog = new Dog();
* alert(myDog.warmBlooded);//true
*/
Shaolin.extend = function (subC, supC) {
	var I = function () {};
	I.prototype = supC.prototype;
	subC.prototype = new I();
	subC.prototype.constructor = subC;
	subC.prototype._uber = function (proto, method) {
		var result;
		if (typeof method === "undefined" || method === null || method === "") {
			method = "constructor";
		}
		result = proto[method].apply(this, Array.prototype.slice.call(arguments, 2));
		return result;
	};
};

/**
* Provides object stubs for a namespace.
* @param {String} path The namespace path (delimited by ".").
* @returns {Object} The "outermost" namespace object stub.
* @example
* var ns = Shaolin.provide("Shaolin.UI.Behaviors");
* alert(Shaolin.UI.Behaviors); //object
*/
Shaolin.provide = function (path) {
	var parts = path.split("."),
		current = Shaolin.global,
		i,
		len = parts.length,
		part;
	for (i = 0; i < len; i += 1) {
		part = parts[i];
		if (typeof current[part] === "undefined") {
			current[part] = {};
		}
		current = current[part];
	}
	return current;
};

/**
* Returns the first HTML element that matches the specified CSS selector within the specified context.
* <br/><br/>
* Optionally you can pass an Object in lieu of a CSS selector. If the Object is a HTML element
* it will be returned if it is not a HTML element undefined will be returned.
* @param {String or Object} selector A css selector
* @param {Object} context An element or document to use as the context for finding elements. The default is the current document.
* @returns {Object} The first HTML element that matches the CSS selector within the specified context.
* @example
* var div = Shaolin.getDOM("#myDiv");
* alert(div); //Div element with ID = myDiv
* var p = Shaolin.getDOM("p", div);
* alert(p); //First p element in the myDiv div
*/
Shaolin.getDOM = function (selector, context) {
	var typeOf = typeof selector;
	if (typeOf === "string") {
		return Shaolin.global.Sizzle(selector, context)[0];
	} else {
		if (selector.nodeType === 1 || selector.nodeType === 9) {
			return selector;
		} else {
			if (typeOf === "object" && typeof selector.setInterval !== "undefined") {
				return selector;
			} else {
				return undefined;
			}
		}
	}
};

/**
* Returns an array of HTML elements that match the specified CSS selector within the specified context.<br/><br/>
* If no HTML elements match the CSS selector, an empty array is returned.
* @param {String or Object} selector A css selector
* @param {Object} context An element or document to use as the context for finding elements. The default is the current document.
* @returns {Array} An array of HTML elements that match the specified CSS selector within the specified context.
* @example
* var paragraphs = Shaolin.getDOMList("#myDiv p"); //An array of p elements
*/
Shaolin.getDOMList = function (selector, context) {
	if (typeof selector === "string") {
		return Shaolin.global.Sizzle(selector, context);
	} else {
		return [];
	}
};