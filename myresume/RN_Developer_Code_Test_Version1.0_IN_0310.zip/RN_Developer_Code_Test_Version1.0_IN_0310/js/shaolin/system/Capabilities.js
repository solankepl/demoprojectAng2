//#include shaolin/Shaolin.js
//#include shaolin/com/modernizr.js
//#include shaolin/com/swfobject.js

Shaolin.provide("Shaolin.System");

/**
* @namespace
* @requires Shaolin
* @requires modernizr
* @requires swfobject
* @property {Boolean} volume
* @property {Boolean} flash
*/
Shaolin.System.Capabilities = (function () {
	Modernizr.addTest("volume", function () {
		var test = document.createElement("audio");
		test.volume = 0.5;
		return Modernizr.audio && test.volume === 0.5;
	});
	Modernizr.addTest("flash", function () {
		return swfobject.hasFlashPlayerVersion("9.0.28"); //:KLUDGE: 9.0.28 is required version for polyfills
	});
	return Modernizr;
}());