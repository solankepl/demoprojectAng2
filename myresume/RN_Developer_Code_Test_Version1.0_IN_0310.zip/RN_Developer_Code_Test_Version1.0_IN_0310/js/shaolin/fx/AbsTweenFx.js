//#include shaolin/Shaolin.js
//#include shaolin/fx/AbsFx.js
//#include shaolin/fx/easing/Linear.js
//#include shaolin/fx/easing/Quadratic.js
//#include shaolin/signals/NativeSignal.js
//#include shaolin/system/Capabilities.js

Shaolin.provide("Shaolin.Fx");

/**
* @param {String or HTMLElement} target
* @param {Number} duration
* @param {String} easing
* @class
* @augments Shaolin.Fx.AbsFx
* @requires Shaolin
* @requires Shaolin.Fx.AbsFx
* @requires Shaolin.Fx.Easing.Linear
* @requires Shaolin.Fx.Easing.Quadratic
* @requires Shaolin.Signals.NativeSignal
* @requires Shaolin.System.Capabilities
*/
Shaolin.Fx.AbsTweenFx = (function () {
	var Constr,
		AbsFx = Shaolin.Fx.AbsFx.prototype,
		Linear = Shaolin.Fx.Easing.Linear,
		Quadratic = Shaolin.Fx.Easing.Quadratic,
		NativeSignal = Shaolin.Signals.NativeSignal,
		Capabilities = Shaolin.System.Capabilities;
	/** @exports Constr as Shaolin.Fx.AbsTweenFx */
	Constr = function (target, duration, easing) {
		this._uber(AbsFx, "");
		this._target = Shaolin.getDOM(target);
		if (this._target) {
			this._duration = duration || 500;
			this._easing = easing || "ease-out";
			this._hasTrans = Capabilities.csstransitions;
			this._transStr = "";
			this._readyID = NaN;
		} else {
			throw new Error("Target is undefined.");
		}
	};
	Shaolin.extend(Constr, AbsFx.constructor);
	Constr.prototype = (function (p) {
		p._target = undefined;
		p._duration = undefined;
		p._easing = undefined;
		p._hasTrans = undefined;
		p._transStr = undefined;
		p._readyID = undefined;
		p._transEnd = undefined;
		p._markInitialSettings = function () {};
		p._restoreInitialSettings = function () {};
		p._attachTrans = function () {
			var prefixedTranName = Capabilities.prefixed("transition"),
				curTransStr = this._target.style[prefixedTranName],
				transEndEventNames = {
					WebkitTransition: "webkitTransitionEnd",
					MozTransition: "transitionend",
					OTransition: "oTransitionEnd",
					msTransition: "MSTransitionEnd",
					transition: "transitionend"
				};
			if (curTransStr !== "") {
				curTransStr += ", " + this._transStr;
			} else {
				curTransStr = this._transStr;
			}
			this._target.style[prefixedTranName] = curTransStr;
			if (!this._transEnd) {
				this._transEnd = new NativeSignal(this._target, transEndEventNames[prefixedTranName]);
				this._transEnd.add(this._handleTranMotionFinished, this);
			}
		};
		p._detachTrans = function () {
			var regEx = new RegExp("(^|,| ,)" + this._transStr + "(,| ,|$)"),
				prefixedTranName = Capabilities.prefixed("transition"),
				targetStyle = this._target.style[prefixedTranName],
				//IE10 is dropping the " 0s" delay portion of the transition string
				//here we set up an alternative string without the " 0s" portion
				altRegEx = new RegExp(" 0s", "g"),
				altTransStr = this._transStr.replace(altRegEx, "");
				//
			targetStyle = targetStyle.replace(regEx, "$1");
			targetStyle = targetStyle.replace(/ $/, "");
			//check for the alternative version without the " 0s" delay portion (needed for IE10) 
			regEx = new RegExp("(^|,| ,)" + altTransStr + "(,| ,|$)");
			targetStyle = targetStyle.replace(regEx, "$1");
			targetStyle = targetStyle.replace(/ $/, "");
			//
			this._target.style[prefixedTranName] = targetStyle;
			this._transStr = "";
			this._transEnd.removeAll();
			this._transEnd = undefined;
		};
		p._durationToString = function () {
			var secs = Math.round((this._duration / 1000) * 10) / 10;
			return secs + "s";
		};
		p._easingToClass = function () {
			switch (this._easing) {
			case "ease-in":
				return Quadratic.easeIn;
			case "ease":
				return Quadratic.easeOut;
			case "ease-out":
				return Quadratic.easeOut;
			case "ease-in-out":
				return Quadratic.easeInOut;
			default:
				return Linear.easeInOut;
			}
		};
		p._calcComputedStyle = function (el, style, asNumber) {
			var computedStyle,
				returnVal;
			asNumber = asNumber || false;
			if (typeof el.currentStyle !== "undefined") {
				computedStyle = el.currentStyle;
			} else {
				computedStyle = document.defaultView.getComputedStyle(el, null);
			}
			try {
				returnVal = computedStyle[style];
			} catch (e) {
				returnVal = "";
			}
			if (asNumber) {
				returnVal = parseInt(returnVal, 10);
				return (isNaN(returnVal)) ? 0 : returnVal;
			} else {
				return returnVal;
			}
		};
		p._handleReady = function (initState) {
			this._readyID = NaN;
			this._isInit = true;
			this._init.dispatch([this, this._state]);
		};
		p._handleTranMotionFinished = function (evt) {
			this._motionFinished.dispatch([this, this._state]);
		};
		p.init = function (initState) { //override
			if (!this._isInit) {
				this._markInitialSettings();
				this._state = (this._isValidState(initState)) ? initState : "off";
				if (this._state === "off") {
					this._toOff();
				} else {
					this._toOn();
				}
				this._readyID = setTimeout(Shaolin.bind(this._handleReady, this), 20, initState); //delay notification
			}
		};
		p.kill = function (initState) {
			if (!isNaN(this._readyID)) {
				clearTimeout(this._readyID);
				this._readyID = NaN;
			}
			if (this._isInit) {
				this._restoreInitialSettings();
			}
			this._uber(AbsFx, "kill");
		};
		return p;
	}(Constr.prototype));
	return Constr;
}());