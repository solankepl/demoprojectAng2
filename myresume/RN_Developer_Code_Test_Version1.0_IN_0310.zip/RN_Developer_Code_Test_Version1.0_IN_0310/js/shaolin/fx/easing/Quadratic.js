//#include shaolin/Shaolin.js

Shaolin.provide("Shaolin.Fx.Easing");

/**
* @class
* @static
* @requires Shaolin
*/
Shaolin.Fx.Easing.Quadratic = (function () {
	return {
		/**
		* @param {Number} t
		* @param {Number} b
		* @param {Number} c
		* @param {Number} d
		* @returns {Number}
		* @exports easeIn as Shaolin.Fx.Easing.Quadratic#easeIn
		*/
		easeIn: function (t, b, c, d) {
			return c * (t /= d) * t + b;
		},
		/**
		* @param {Number} t
		* @param {Number} b
		* @param {Number} c
		* @param {Number} d
		* @returns {Number}
		* @exports easeOut as Shaolin.Fx.Easing.Quadratic#easeOut
		*/
		easeOut: function (t, b, c, d) {
			return -c * (t /= d) * (t - 2) + b;
		},
		/**
		* @param {Number} t
		* @param {Number} b
		* @param {Number} c
		* @param {Number} d
		* @returns {Number}
		* @exports easeInOut as Shaolin.Fx.Easing.Quadratic#easeInOut
		*/
		easeInOut: function (t, b, c, d) {
			if ((t /= d / 2) < 1) {
				return c / 2 * t * t + b;
			} else {
				t -= 1;
				return -c / 2 * (t * (t - 2) - 1) + b;
			}
		}
	};
}());