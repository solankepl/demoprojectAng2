//#include shaolin/Shaolin.js

Shaolin.provide("Shaolin.Fx.Easing");

/**
* @class
* @static
* @requires Shaolin
*/
Shaolin.Fx.Easing.Linear = (function () {
	return {
		/**
		* @param {Number} t
		* @param {Number} b
		* @param {Number} c
		* @param {Number} d
		* @returns {Number}
		* @exports easeIn as Shaolin.Fx.Easing.Linear#easeIn
		*/
		easeIn: function (t, b, c, d) {
			return (c * (t / d)) + b;
		},
		/**
		* @param {Number} t
		* @param {Number} b
		* @param {Number} c
		* @param {Number} d
		* @returns {Number}
		* @exports easeOut as Shaolin.Fx.Easing.Linear#easeOut
		*/
		easeOut: function (t, b, c, d) {
			return (c * (t / d)) + b;
		},
		/**
		* @param {Number} t
		* @param {Number} b
		* @param {Number} c
		* @param {Number} d
		* @returns {Number}
		* @exports easeInOut as Shaolin.Fx.Easing.Linear#easeInOut
		*/
		easeInOut: function (t, b, c, d) {
			return (c * (t / d)) + b;
		}
	};
}());