//#include shaolin/Shaolin.js
//#include shaolin/fx/easing/Linear.js
//#include shaolin/signals/Signal.js
//#include shaolin/utils/Timer.js

Shaolin.provide("Shaolin.Fx");

/**
* @param {Number} begin
* @param {Number} finish
* @param {Number} duration
* @param {Function} easing
* @param {Number} frameRate
* @class
* @requires Shaolin
* @requires Shaolin.Fx.Easing.Linear
* @requires Shaolin.Signals.Signal
* @requires Shaolin.Utils.Timer
*/
Shaolin.Fx.Tween = (function () {
	var Constr,
		Linear = Shaolin.Fx.Easing.Linear,
		Signal = Shaolin.Signals.Signal,
		Timer = Shaolin.Utils.Timer;
	/** @exports Constr as Shaolin.Fx.Tween */
	Constr = function (begin, finish, duration, easing, frameRate) {
		this._begin = begin;
		this._finish = finish;
		this._duration = duration || 1000;
		this._easing = easing || Linear.easeInOut;
		this._frameRate = frameRate || 30;
		this._isPlaying = false;
		this._direction = "forward";
		this._time = NaN;
		this._position = this._begin;
		this._change = this._finish - this._begin;
		this._tick = 1000 / this._frameRate;
		this._motionStarted = new Signal([Object, String, Number]);
		this._motionStopped = new Signal([Object, String, Number]);
		this._motionChanged = new Signal([Object, String, Number]);
		this._motionFinished = new Signal([Object, String, Number]);
	};
	Constr.prototype = (function (p) {
		p._begin = undefined;
		p._finish = undefined;
		p._duration = undefined;
		p._easing = undefined;
		p._frameRate = undefined;
		p._isPlaying = undefined;
		p._direction = undefined;
		p._time = undefined;
		p._position = undefined;
		p._change = undefined;
		p._tick = undefined;
		p._motionStarted = undefined;
		p._motionStopped = undefined;
		p._motionChanged = undefined;
		p._motionFinished = undefined;
		p._timer = undefined;
		p._initTimer = function (tickCount) {
			this._timer = new Timer(this._tick, tickCount);
			this._timer.getTicked().add(this._handleTimerTicked, this);
			this._timer.getCompleted().addOnce(this._handleTimerCompleted, this);
			this._timer.start();
		};
		p._releaseTimer = function () {
			this._timer.stop();
			this._timer.getTicked().remove(this._handleTimerTicked, this);
			this._timer.getCompleted().remove(this._handleTimerCompleted, this);
			this._timer = undefined;
		};
		p._handleTimerTicked = function (timer) {
			switch (this._direction) {
			case "backward":
				this._moveBackward();
				break;
			case "forward":
				this._moveForward();
				break;
			}
		};
		p._handleTimerCompleted = function (timer) {
			this._isPlaying = false;
			this._motionFinished.dispatch([this, this._direction, this._position]);
		};
		p._moveBackward = function () {
			this._time -= this._tick;
			if (this._time < 0) {
				this._time = 0;
			}
			this._updatePos();
			this._motionChanged.dispatch([this, this._direction, this._position]);
		};
		p._moveForward = function () {
			this._time += this._tick;
			if (this._time > this._duration) {
				this._time = this._duration;
			}
			this._updatePos();
			this._motionChanged.dispatch([this, this._direction, this._position]);
		};
		p._updatePos = function () {
			var result = "";
			this._position = this._easing(this._time, this._begin, this._change, this._duration);
		};
		/**
		* @returns {Boolean}
		* @exports p.getIsPlaying as Shaolin.Fx.Tween#getIsPlaying
		*/
		p.getIsPlaying = function () {
			return this._isPlaying;
		};
		/**
		* @returns {String}
		* @exports p.getDirection as Shaolin.Fx.Tween#getDirection
		*/
		p.getDirection = function () {
			return this._direction;
		};
		/**
		* @returns {Number}
		* @exports p.getPosition as Shaolin.Fx.Tween#getPosition
		*/
		p.getPosition = function () {
			return this._position;
		};
		/**
		* @returns {Shaolin.Signals.Signal}
		* @exports p.getMotionStarted as Shaolin.Fx.Tween#getMotionStarted
		*/
		p.getMotionStarted = function () {
			return this._motionStarted;
		};
		/**
		* @returns {Shaolin.Signals.Signal}
		* @exports p.getMotionStopped as Shaolin.Fx.Tween#getMotionStopped
		*/
		p.getMotionStopped = function () {
			return this._motionStopped;
		};
		/**
		* @returns {Shaolin.Signals.Signal}
		* @exports p.getMotionChanged as Shaolin.Fx.Tween#getMotionChanged
		*/
		p.getMotionChanged = function () {
			return this._motionChanged;
		};
		/**
		* @returns {Shaolin.Signals.Signal}
		* @exports p.getMotionFinished as Shaolin.Fx.Tween#getMotionFinished
		*/
		p.getMotionFinished = function () {
			return this._motionFinished;
		};
		/**
		* @exports p.play as Shaolin.Fx.Tween#play
		*/
		p.play = function () {
			var tickCount;
			if (this._isPlaying) {
				this._releaseTimer();
			} else {
				this._isPlaying = true;
			}
			this._direction = "forward";
			if (isNaN(this._time)) {
				this._time = 0;
			}
			this._updatePos();
			this._motionStarted.dispatch([this, this._direction, this._position]);
			tickCount = Math.round(this._frameRate * ((this._duration - this._time) / 1000));
			this._initTimer(tickCount);
		};
		/**
		* @exports p.rewind as Shaolin.Fx.Tween#rewind
		*/
		p.rewind = function () {
			var tickCount;
			if (this._isPlaying) {
				this._releaseTimer();
			} else {
				this._isPlaying = true;
			}
			this._direction = "backward";
			if (isNaN(this._time)) {
				this._time = this._duration;
			}
			this._updatePos();
			this._motionStarted.dispatch([this, this._direction, this._position]);
			tickCount = Math.round(this._frameRate * (this._time / 1000));
			this._initTimer(tickCount);
		};
		/**
		* @exports p.stop as Shaolin.Fx.Tween#stop
		*/
		p.stop = function () {
			if (this._isPlaying) {
				this._isPlaying = false;
				this._releaseTimer();
				this._motionStopped.dispatch([this, this._direction, this._position]);
			}
		};
		return p;
	}(Constr.prototype));
	return Constr;
}());