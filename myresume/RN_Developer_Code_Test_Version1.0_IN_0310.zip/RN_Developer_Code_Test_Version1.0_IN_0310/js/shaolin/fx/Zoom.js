//#include shaolin/Shaolin.js
//#include shaolin/fx/AbsTweenFx.js
//#include shaolin/fx/Tween.js
//#include shaolin/system/Capabilities.js

Shaolin.provide("Shaolin.Fx");

/**
* @param {String or HTMLElement} target
* @param {Number} wFrom
* @param {Number} wTo
* @param {Number} hFrom
* @param {Number} hTo
* @param {Number} xOrigin
* @param {Number} yOrigin
* @param {Number} duration
* @param {String} easing
* @class
* @augments Shaolin.Fx.AbsTweenFx
* @requires Shaolin
* @requires Shaolin.Fx.AbsTweenFx
* @requires Shaolin.Fx.Tween
* @requires Shaolin.System.Capabilities
*/
Shaolin.Fx.Zoom = (function () {
	var Constr,
		AbsTweenFx = Shaolin.Fx.AbsTweenFx.prototype,
		Capabilities = Shaolin.System.Capabilities,
		Tween = Shaolin.Fx.Tween;
	/** @exports Constr as Shaolin.Fx.Zoom */
	Constr = function (target, xFrom, xTo, yFrom, yTo, xOrigin, yOrigin, duration, easing) {
		this._uber(AbsTweenFx, "", target, duration, easing);
		if (!isNaN(xFrom)) {
			this._xFrom = xFrom;
		} else {
			this._xFrom = 1;
		}
		if (!isNaN(xTo)) {
			this._xTo = xTo;
		} else {
			this._xTo = 1;
		}
		if (!isNaN(yFrom)) {
			this._yFrom = yFrom;
		} else {
			this._yFrom = this._xFrom;
		}
		if (!isNaN(yTo)) {
			this._yTo = yTo;
		} else {
			this._yTo = this._xTo;
		}
		if (!isNaN(xOrigin)) {
			this._xOrigin = xOrigin;
		} else {
			this._xOrigin = 50;
		}
		if (!isNaN(yOrigin)) {
			this._yOrigin = yOrigin;
		} else {
			this._yOrigin = this._xOrigin;
		}
	};
	Shaolin.extend(Constr, AbsTweenFx.constructor);
	Constr.prototype = (function (p) {
		p._xFrom = undefined;
		p._xTo = undefined;
		p._yFrom = undefined;
		p._yTo = undefined;
		p._xOrigin = undefined;
		p._yOrigin = undefined;
		p._prefixedTrans = undefined;
		p._prefixedTransHy = undefined;
		p._prefixedTransOrigin = undefined;
		p._initFilter = undefined;
		p._wInit = undefined;
		p._hInit = undefined;
		p._leftInit = undefined;
		p._topInit = undefined;
		p._wFrom = undefined;
		p._hFrom = undefined;
		p._leftFrom = undefined;
		p._topFrom = undefined;
		p._wTo = undefined;
		p._hTo = undefined;
		p._leftTo = undefined;
		p._topTo = undefined;
		p._tweenX = undefined;
		p._tweenY = undefined;
		p._tweenLeft = undefined;
		p._tweenTop = undefined;
		p._tweenXChanged = undefined;
		p._tweenXPos = undefined;
		p._tweenYChanged = undefined;
		p._tweenYPos = undefined;
		p._totalTweens = undefined;
		p._finishedTweens = undefined;
		p._toOn = function () {
			this._uber(AbsTweenFx, "_toOn");
			if (Capabilities.csstransforms) {
				this._target.style[this._prefixedTrans] = "scale(" + this._xTo + "," + this._yTo + ")";
			} else {
				this._applyFilter(this._xTo, this._yTo);
				this._target.style.left = this._leftTo + "px";
				this._target.style.top = this._topTo + "px";
			}
		};
		p._toOff = function () {
			this._uber(AbsTweenFx, "_toOff");
			if (Capabilities.csstransforms) {
				this._target.style[this._prefixedTrans] = "scale(" + this._xFrom + "," + this._yFrom + ")";
			} else {
				this._applyFilter(this._xFrom, this._yFrom);
				this._target.style.left = this._leftFrom + "px";
				this._target.style.top = this._topFrom + "px";
			}
		};
		p._turnOn = function () {
			if (Capabilities.csstransforms) {
				if (this._hasTrans) {
					this._toOn();
				} else {
					this._tweenX.play();
					this._tweenY.play();
				}
			} else {
				this._tweenX.play();
				this._tweenY.play();
				this._tweenLeft.play();
				this._tweenTop.play();
			}
			this._uber(AbsTweenFx, "_turnOn");
		};
		p._turnOff = function () {
			if (Capabilities.csstransforms) {
				if (this._hasTrans) {
					this._toOff();
				} else {
					this._tweenX.rewind();
					this._tweenY.rewind();
				}
			} else {
				this._tweenX.rewind();
				this._tweenY.rewind();
				this._tweenLeft.rewind();
				this._tweenTop.rewind();
			}
			this._uber(AbsTweenFx, "_turnOff");
		};
		p._markInitialSettings = function () {
			this._uber(AbsTweenFx, "_markInitialSettings");
			if (Capabilities.csstransforms) {
				this._prefixedTrans = Capabilities.prefixed("transform");
				this._prefixedTransHy = this._prefixedTrans.replace(/([A-Z])/g, function (str, m1) { return '-' + m1.toLowerCase(); }).replace(/^ms-/, '-ms-');
				this._prefixedTransOrigin = Capabilities.prefixed("transformOrigin");
				this._target.style[this._prefixedTransOrigin] = this._xOrigin + "% " + this._yOrigin + "%";
			} else {
				var fromOrigin,
					toOrigin;
				this._initFilter = this._calcComputedStyle(this._target, "filter") || "";
				//perform calculations here to determine the left and top positions for to and from....
				this._wInit = this._target.offsetWidth;
				this._hInit = this._target.offsetHeight;
				this._leftInit = this._calcComputedStyle(this._target, "left", true);
				this._topInit = this._calcComputedStyle(this._target, "top", true);
				//measure the dimensions of the element when effect is "off"
				//we temporarily apply the filter to grab those values
				this._target.style.filter = "progid:DXImageTransform.Microsoft.Matrix(M11=" + this._xFrom + ", M12=0, M21=0, M22=" + this._yFrom + ", SizingMethod='auto expand')";
				this._wFrom = this._target.offsetWidth;
				this._hFrom = this._target.offsetHeight;
				this._target.style.filter = this._initFilter;
				//measure the dimensions of the element when effect is "on"
				//we temporarily apply the filter to grab those values
				this._target.style.filter = "progid:DXImageTransform.Microsoft.Matrix(M11=" + this._xTo + ", M12=0, M21=0, M22=" + this._yTo + ", SizingMethod='auto expand')";
				this._wTo = this._target.offsetWidth;
				this._hTo = this._target.offsetHeight;
				this._target.style.filter = this._initFilter;
				//calculate origins (as left and top positions)
				fromOrigin = this._calcOriginPos(this._wInit, this._hInit, this._wFrom, this._hFrom, this._xFrom, this._yFrom, this._xOrigin, this._yOrigin);
				this._leftFrom = this._leftInit + fromOrigin.left;
				this._topFrom = this._topInit + fromOrigin.top;
				toOrigin = this._calcOriginPos(this._wInit, this._hInit, this._wTo, this._hTo, this._xTo, this._yTo, this._xOrigin, this._yOrigin);
				this._leftTo = this._leftInit + toOrigin.left;
				this._topTo = this._topInit + toOrigin.top;
			}
		};
		p._restoreInitialSettings = function () {
			this._uber(AbsTweenFx, "_restoreInitialSettings");
			if (Capabilities.csstransforms) {
				if (this._hasTrans) {
					this._detachTrans();
				} else {
					this._tweenX.stop();
					this._tweenX.getMotionChanged().removeAll();
					this._tweenX.getMotionFinished().removeAll();
					this._tweenY.stop();
					this._tweenY.getMotionChanged().removeAll();
					this._tweenY.getMotionFinished().removeAll();
				}
				this._target.style[this._prefixedTrans] = "";
				this._target.style[this._prefixedTransOrigin] = "";
			} else {
				this._tweenX.stop();
				this._tweenX.getMotionChanged().removeAll();
				this._tweenX.getMotionFinished().removeAll();
				this._tweenY.stop();
				this._tweenY.getMotionChanged().removeAll();
				this._tweenY.getMotionFinished().removeAll();
				this._tweenLeft.stop();
				this._tweenLeft.getMotionChanged().removeAll();
				this._tweenLeft.getMotionFinished().removeAll();
				this._tweenTop.stop();
				this._tweenTop.getMotionChanged().removeAll();
				this._tweenTop.getMotionFinished().removeAll();
				this._removeFilter();
				this._target.style.filter = this._initFilter;
				this._target.style.left = "";
				this._target.style.top = "";
			}
		};
		p._applyTweenValues = function () {
			this._tweenXChanged = false;
			this._tweenYChanged = false;
			if (Capabilities.csstransforms) {
				this._target.style[this._prefixedTrans] = "scale(" + this._tweenXPos + "," + this._tweenYPos + ")";
			} else {
				this._applyFilter(this._tweenXPos, this._tweenYPos);
			}
		};
		p._applyFilter = function (scaleX, scaleY) {
			this._removeFilter();
			this._target.style.filter += " progid:DXImageTransform.Microsoft.Matrix(M11=" + scaleX + ", M12=0, M21=0, M22=" + scaleY + ", SizingMethod='auto expand')";
		};
		p._removeFilter = function () {
			var regEx = new RegExp("(^| )progid:DXImageTransform.Microsoft.Matrix\\(M11=[0-9]{1,}.{0,}[0-9]{0,}\\, M12=0\\, M21=0\\, M22=[0-9]{1,}.{0,}[0-9]{0,}\\, SizingMethod=\\'auto expand\\'\\)( |$)"),
				filterStyle = this._calcComputedStyle(this._target, "filter");
			filterStyle = filterStyle.replace(regEx, "$1");
			filterStyle = filterStyle.replace(/ $/, "");
			this._target.style.filter = filterStyle;
		};
		p._calcOriginPos = function (bW, bH, tW, tH, sX, sY, oX, oY) {
			var centerX,
				centerY,
				originX,
				originY,
				tCenterX,
				tCenterY,
				tOriginX,
				tOriginY,
				left,
				top;
			//following calculation comes from: http://someguynameddylan.com/lab/transform-origin-in-internet-explorer.php
			//calculates the proper origin of the zoom and returns the proper left and top positions
			//bW = base or default width of the element
			//bH = base or default height of the element
			//tW = scaled width of the element
			//tH = scaled height of the element
			//sX = scale modifier for width 
			//sY = scale modifier for height
			//oX = the origin (percentage) for X
			//oY = the origin (percentage) for Y
			//1. dimensions of element (passed as bW, bH)
			//2. get center of element and translate it
			centerX = bW / 2;
			centerY = bH / 2;
			oX = bW * (oX / 100);
			oY = bH * (oY / 100);
			tCenterX = centerX - oX;
			tCenterY = centerY - oY;
			//3. apply matrix transform to result
			tOriginX = (sX * tCenterX) + oX;
			tOriginY = (sY * tCenterY) + oY;
			//4. translate the result by the transform origin
			//5. subtract from the x value of the result half the width of the bounding box, and from the y value of the result half the height of the bounding box
			left = Math.floor(tOriginX - (tW / 2));
			top = Math.floor(tOriginY - (tH / 2));
			//
			return {left: left, top: top};
		};
		p._handleReady = function (initState) {
			if (this._hasTrans && Capabilities.csstransforms) {
				this._transStr = this._prefixedTransHy + " " + this._durationToString() + " " + this._easing + " 0s";
				this._attachTrans();
			} else {
				var easingClass = this._easingToClass();
				this._totalTweens = 2;
				this._finishedTweens = 0;
				this._tweenX = new Tween(
					this._xFrom,
					this._xTo,
					this._duration,
					easingClass
				);
				this._tweenXChanged = false;
				this._tweenX.getMotionChanged().add(this._handleTweenXMotionChanged, this);
				this._tweenX.getMotionFinished().add(this._handleTweenMotionFinished, this);
				this._tweenY = new Tween(
					this._yFrom,
					this._yTo,
					this._duration,
					easingClass
				);
				this._tweenYChanged = false;
				this._tweenY.getMotionChanged().add(this._handleTweenYMotionChanged, this);
				this._tweenY.getMotionFinished().add(this._handleTweenMotionFinished, this);
				if (!Capabilities.csstransforms) {
					this._totalTweens += 2;
					this._tweenLeft = new Tween(
						this._leftFrom,
						this._leftTo,
						this._duration,
						easingClass
					);
					this._tweenLeft.getMotionChanged().add(this._handleTweenLeftMotionChanged, this);
					this._tweenLeft.getMotionFinished().add(this._handleTweenMotionFinished, this);
					this._tweenTop = new Tween(
						this._topFrom,
						this._topTo,
						this._duration,
						easingClass
					);
					this._tweenTop.getMotionChanged().add(this._handleTweenTopMotionChanged, this);
					this._tweenTop.getMotionFinished().add(this._handleTweenMotionFinished, this);
				}
			}
			this._uber(AbsTweenFx, "_handleReady", initState);
		};
		p._handleTranMotionFinished = function (evt) { //override
			if (evt.propertyName === this._prefixedTransHy) {
				this._motionFinished.dispatch([this, this._state]);
			}
		};
		p._handleTweenXMotionChanged = function (tween, direction, position) {
			this._tweenXPos = position;
			this._tweenXChanged = true;
			if (this._tweenYChanged) {
				this._applyTweenValues();
			}
		};
		p._handleTweenYMotionChanged = function (tween, direction, position) {
			this._tweenYPos = position;
			this._tweenYChanged = true;
			if (this._tweenXChanged) {
				this._applyTweenValues();
			}
		};
		p._handleTweenLeftMotionChanged = function (tween, direction, position) {
			this._target.style.left = position + "px";
		};
		p._handleTweenTopMotionChanged = function (tween, direction, position) {
			this._target.style.top = position + "px";
		};
		p._handleTweenMotionFinished = function (tween, direction, position) {
			this._finishedTweens += 1;
			if (this._finishedTweens === this._totalTweens) {
				this._finishedTweens = 0;
				this._motionFinished.dispatch([this, this._state]);
			}
		};
		return p;
	}(Constr.prototype));
	return Constr;
}());