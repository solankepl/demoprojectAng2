//#include shaolin/Shaolin.js
//#include shaolin/signals/Signal.js

Shaolin.provide("Shaolin.Fx");

/**
* @class
* @requires Shaolin
* @requires Shaolin.Signals.Signal
*/
Shaolin.Fx.AbsFx = (function () {
	var Constr,
		Signal = Shaolin.Signals.Signal;
	/** @exports Constr as Shaolin.Fx.AbsFx */
	Constr = function () {
		this._isInit = false;
		this._init = new Signal([Object, String]);
		this._motionStarted = new Signal([Object, String]);
		this._motionFinished = new Signal([Object, String]);
		this._killed = new Signal([Object]);
	};
	Constr.prototype = (function (p) {
		p._isInit = undefined;
		p._init = undefined;
		p._motionStarted = undefined;
		p._motionFinished = undefined;
		p._killed = undefined;
		p._state = undefined;
		p._isValidState = function (theState) {
			if (theState === "on" || theState === "off") {
				return true;
			} else {
				return false;
			}
		};
		p._toOn = function () {};
		p._toOff = function () {};
		p._turnOn = function () {
			this._motionStarted.dispatch([this, this._state]);
		};
		p._turnOff = function () {
			this._motionStarted.dispatch([this, this._state]);
		};
		/**
		* @returns {Shaolin.Signals.Signal}
		* @exports p.getInit as Shaolin.Fx.AbsFx#getInit
		*/
		p.getInit = function () {
			return this._init;
		};
		/**
		* @param {String} initState
		* @exports p.init as Shaolin.Fx.AbsFx#init
		*/
		p.init = function (initState) {
			if (!this._isInit) {
				this._isInit = true;
				this._state = (this._isValidState(initState)) ? initState : "off";
				if (this._state === "off") {
					this._toOff();
				} else {
					this._toOn();
				}
				this._init.dispatch([this, this._state]);
			}
		};
		/**
		* @returns {Shaolin.Signals.Signal}
		* @exports p.getMotionStarted as Shaolin.Fx.AbsFx#getMotionStarted
		*/
		p.getMotionStarted = function () {
			return this._motionStarted;
		};
		/**
		* @returns {Shaolin.Signals.Signal}
		* @exports p.getMotionFinished as Shaolin.Fx.AbsFx#getMotionFinished
		*/
		p.getMotionFinished = function () {
			return this._motionFinished;
		};
		/**
		* @returns {Shaolin.Signals.Signal}
		* @exports p.getKilled as Shaolin.Fx.AbsFx#getKilled
		*/
		p.getKilled = function () {
			return this._killed;
		};
		/**
		* @exports p.kill as Shaolin.Fx.AbsFx#kill
		*/
		p.kill = function () {
			if (this._isInit) {
				this._isInit = false;
				this._state = undefined;
				this._killed.dispatch([this]);
			}
		};
		/**
		* @returns {String}
		* @exports p.getState as Shaolin.Fx.AbsFx#getState
		*/
		p.getState = function () {
			return this._state;
		};
		/**
		* @param {String} newState
		* @returns {Boolean}
		* @exports p.setState as Shaolin.Fx.AbsFx#setState
		*/
		p.setState = function (newState) {
			if (this._isInit && newState !== this._state && this._isValidState(newState)) {
				this._state = newState;
				if (this._state === "on") {
					this._turnOn();
				} else {
					this._turnOff();
				}
				return true;
			} else {
				return false;
			}
		};
		return p;
	}(Constr.prototype));
	return Constr;
}());