//#include shaolin/Shaolin.js

Shaolin.provide("Shaolin.Signals");

/**
* @param {Array} valueClasses
* @throws {Error} If any value class is not a valid Function.
* @class
* @requires Shaolin
*/
Shaolin.Signals.Signal = (function () {
	var Constr;
	/** @exports Constr as Shaolin.Signals.Signal */
	Constr = function (valueClasses) {
		var i,
			len;
		this._listeners = [];
		this._valueClasses = valueClasses || [];
		len = this._valueClasses.length - 1;
		for (i = len; i >= 0; i -= 1) {
			if (!(this._valueClasses[i] instanceof Function)) {
				throw new Error("Invalid valueClass (" + i + "): Expecting function.");
			}
		}
	};
	Constr.prototype = (function (p) {
		p._listeners = undefined;
		p._valueClasses = undefined;
		p._registerListener = function (listener, scope, isOnce) {
			//:TODO: add in basic check to see if listener actually exists
			var numListeners,
				i,
				curListener;
			if (listener.length < this._valueClasses.length) {
				throw new Error("Listener does not define enough arguments.");
			}
			numListeners = this._listeners.length;
			if (numListeners === 0) {
				this._listeners[0] = {listener: listener, scope: scope, isOnce: isOnce};
				return;
			}
			for (i = 0; i < numListeners; i += 1) {
				curListener = this._listeners[i];
				if (curListener.listener === listener && curListener.scope === scope) {
					if (curListener.isOnce && !isOnce) {
						throw new Error("You cannot addOnce() then add() the same listener without removing the relationship first.");
					} else if (!curListener.isOnce && isOnce) {
						throw new Error("You cannot add() then addOnce() the same listener without removing the relationship first.");
					} else {
						throw new Error("You cannot add()/addOnce() the same listener without removing the relationship first.");
					}
				}
			}
			this._listeners[numListeners] = {listener: listener, scope: scope, isOnce: isOnce};
		};
		/**
		* @returns {Number}
		* @exports p.getNumListeners as Shaolin.Signals.Signal#getNumListeners
		*/
		p.getNumListeners = function () {
			return this._listeners.length;
		};
		/**
		* @param {Function} listener
		* @param {Object} scope
		* @throws {Error} If listener does not define enough arguments
		* @throws {Error} If listener had already been added 
		* @exports p.add as Shaolin.Signals.Signal#add
		*/
		p.add = function (listener, scope) {
			this._registerListener(listener, scope, false);
		};
		/**
		* @param {Function} listener
		* @param {Object} scope
		* @throws {Error} If listener does not define enough arguments
		* @throws {Error} If listener had already been added 
		* @exports p.addOnce as Shaolin.Signals.Signal#addOnce
		*/
		p.addOnce = function (listener, scope) {
			this._registerListener(listener, scope, true);
		};
		/**
		* @param {Function} listener
		* @param {Object} scope
		* @exports p.remove as Shaolin.Signals.Signal#remove
		*/
		p.remove = function (listener, scope) {
			var numListeners = this._listeners.length,
				index = -1,
				i,
				curListener;
			for (i = 0; i < numListeners && index === -1; i += 1) {
				curListener = this._listeners[i];
				if (curListener.listener === listener && curListener.scope === scope) {
					index = i;
				}
			}
			if (index !== -1) {
				this._listeners.splice(index, 1);
				return true;
			} else {
				return false;
			}
		};
		/**
		* @exports p.removeAll as Shaolin.Signals.Signal#removeAll
		*/
		p.removeAll = function () {
			this._listeners = [];
		};
		/**
		* @param {Array} args
		* @throws {Error} If args array does not match the expected number of arguments defined by valueClasses.
		* @throws {Error} If an argument does not match the expected type defined by valueClasses.
		* @exports p.dispatch as Shaolin.Signals.Signal#dispatch
		*/
		p.dispatch = function (args) {
			var numValueObjects,
				numValueClasses,
				valueObject,
				valueObjectType,
				valueClass,
				valueOk,
				i,
				numListeners,
				dispatchListeners,
				numDispatchListeners,
				onceListeners,
				numOnceListeners,
				curListener,
				curDispatchListener;
			//type checking
			numValueObjects = args.length;
			numValueClasses = this._valueClasses.length;
			if (numValueObjects !== numValueClasses) {
				throw new Error("Incorrect number of arguments. Expected " + numValueClasses + " but received " + numValueObjects + ".");
			}
			for (i = 0; i < numValueClasses; i += 1) {
				valueObject = args[i];
				valueObjectType = typeof valueObject;
				valueClass = this._valueClasses[i];
				valueOk = false;
				if (valueObjectType === "object") {
					if (valueClass === Object) {
						valueOk = true;
					} else if (valueClass === Array) {
						if (Object.prototype.toString.call(valueObject) === "[object Array]") {
							valueOk = true;
						}
					}
				} else {
					//handle primatives
					if (valueObjectType === "string" && (valueClass === String || valueClass === Object)) {
						valueOk = true;
					} else if (valueObjectType === "number" && (valueClass === Number || valueClass === Object)) {
						valueOk = true;
					} else if (valueObjectType === "boolean" && (valueClass === Boolean || valueClass === Object)) {
						valueOk = true;
					}
				}
				if (!valueOk) {
					throw new Error("Value object (" + i + ") is not an instance of valueClass.");
				}
			}
			numListeners = this._listeners.length;
			if (numListeners === 0) {
				return;
			}
			//make a clone of the listeners
			//once we are this point all listeners will fire even if they are removed throughout the dispatch
			//clone allows any updates (like add or remove) throughout dispatch to be handled correctly
			dispatchListeners = this._listeners.slice(0);
			//strip once listeners from listeners array
			//done before dispatch, so any updates (like add or remove) throughout dispatch are handled correctly
			onceListeners = [];
			for (i = 0; i < numListeners; i += 1) {
				curListener = this._listeners[i];
				if (curListener.isOnce) {
					onceListeners.push(i);
				}
			}
			numOnceListeners = onceListeners.length;
			for (i = 0; i < numOnceListeners; i += 1) {
				this._listeners.splice(onceListeners[i], 1);
			}
			//dispatch to listeners
			args = args || [];
			numDispatchListeners = dispatchListeners.length;
			for (i = 0; i < numDispatchListeners; i += 1) {
				curDispatchListener = dispatchListeners[i];
				curDispatchListener.listener.apply(curDispatchListener.scope, args);
			}
		};
		return p;
	}(Constr.prototype));
	return Constr;
}());