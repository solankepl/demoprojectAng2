//#include shaolin/Shaolin.js
//#include shaolin/signals/Signal.js

Shaolin.provide("Shaolin.Signals");

/**
* @param {String or Object} target
* @param {String} eventType
* @throws {Error} If target does not resolve to an HTMLElement.
* @class
* @augments Shaolin.Signals.Signal
* @requires Shaolin
* @requires Shaolin.Signals.Signal
*/
Shaolin.Signals.NativeSignal = (function () {
	var Constr,
		Signal = Shaolin.Signals.Signal.prototype;
	/** @exports Constr as Shaolin.Signals.NativeSignal */
	Constr = function (target, eventType) {
		this._uber(Signal, "", [Object]);
		this._target = Shaolin.getDOM(target);
		if (this._target) {
			this._eventType = eventType;
			this._isListening = false;
			this._bEventListener = Shaolin.bind(this._eventListener, this);
			this._bCleanupListener = Shaolin.bind(this._cleanupListener, this);
		} else {
			throw new Error("Target is undefined.");
		}
	};
	Shaolin.extend(Constr, Signal.constructor);
	Constr.prototype = (function (p) {
		p._target = undefined;
		p._eventType = undefined;
		p._isListening = undefined;
		p._bEventListener = undefined;
		p._bCleanupListener = undefined;
		p._parentWin = undefined;
		p._registerEventListener = function () {
			if (!this._isListening) {
				if (document.addEventListener) {
					this._target.addEventListener(this._eventType, this._bEventListener, false);
				} else if (document.attachEvent) {
					this._target.attachEvent("on" + this._eventType, this._bEventListener);
					this._getParentWin().attachEvent("onunload", this._bCleanupListener);
				}
				this._isListening = true;
			}
		};
		p._unregisterEventListener = function () {
			if (this._isListening) {
				if (document.addEventListener) {
					this._target.removeEventListener(this._eventType, this._bEventListener, false);
				} else if (document.attachEvent) {
					this._target.detachEvent("on" + this._eventType, this._bEventListener);
					this._getParentWin().detachEvent("onunload", this._bCleanupListener);
				}
				this._isListening = false;
			}
		};
		p._eventListener = function (evt) {
			var posX = 0,
				posY = 0;
			//fix event (IE) to include preventDefault and stopPropagation if necessary
			if (!evt.stopPropagation) {
				evt = window.event;
				evt.preventDefault = function () {
					this.returnValue = false;
				};
				evt.stopPropagation = function () {
					this.cancelBubble = true;
				};
			}
			//fix event to include "standardized" mouse position (posX,posY) properties
			if (evt.pageX || evt.pageY) {
				posX = evt.pageX;
				posY = evt.pageY;
			} else if (evt.clientX || evt.clientY) {
				if (document.body) {
					posX = evt.clientX + document.body.scrollLeft + document.documentElement.scrollLeft;
					posY = evt.clientY + document.body.scrollTop + document.documentElement.scrollTop;
				} else {
					posX = evt.clientX;
					posY = evt.clientY;
				}
			}
			evt.posX = posX;
			evt.posY = posY;
			this.dispatch([evt]);
		};
		p._cleanupListener = function (evt) {
			this._unregisterEventListener();
		};
		p._getParentWin = function () {
			var parentDoc;
			if (!this._parentWin) {
				parentDoc = this._target.document || this._target;
				this._parentWin = parentDoc.parentWindow;
			}
			return this._parentWin;
		};
		/**
		* @returns {HTMLElement}
		* @exports p.getTarget as Shaolin.Signals.NativeSignal#getTarget
		*/
		p.getTarget = function () {
			return this._target;
		};
		/**
		* @returns {String}
		* @exports p.getEventType as Shaolin.Signals.NativeSignal#getEventType
		*/
		p.getEventType = function () {
			return this._eventType;
		};
		p.add = function (listener, scope) {
			this._uber(Signal, "add", listener, scope);
			if (this._listeners.length > 0) {
				this._registerEventListener();
			}
		};
		p.addOnce = function (listener, scope) {
			this._uber(Signal, "addOnce", listener, scope);
			if (this._listeners.length > 0) {
				this._registerEventListener();
			}
		};
		p.remove = function (listener, scope) {
			this._uber(Signal, "remove", listener, scope);
			if (this._listeners.length === 0) {
				this._unregisterEventListener();
			}
		};
		p.removeAll = function () {
			this._uber(Signal, "removeAll");
			this._unregisterEventListener();
		};
		p.dispatch = function (args) {
			this._uber(Signal, "dispatch", args);
			if (this._listeners.length === 0) {
				this._unregisterEventListener();
			}
		};
		return p;
	}(Constr.prototype));
	return Constr;
}());