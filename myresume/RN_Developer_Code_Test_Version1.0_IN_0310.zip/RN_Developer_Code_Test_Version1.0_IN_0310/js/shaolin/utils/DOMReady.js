//#include shaolin/Shaolin.js
//#include shaolin/signals/NativeSignal.js
//#include shaolin/signals/Signal.js

Shaolin.provide("Shaolin.Utils");

//adpated from: https://github.com/dperini/ContentLoaded/blob/master/src/contentloaded.js

/**
* @param {HTMLElement} win
* @class
* @requires Shaolin
* @requires Shaolin.Signals.NativeSignal
* @requires Shaolin.Signals.Signal
*/
Shaolin.Utils.DOMReady = (function () {
	var Constr,
		Signal = Shaolin.Signals.Signal,
		NativeSignal = Shaolin.Signals.NativeSignal;
	/** @exports Constr as Shaolin.Utils.DOMReady */
	Constr = function (win) {
		var top = true;
		this._win = win || Shaolin.global;
		this._doc = this._win.document;
		this._root = this._doc.documentElement;
		this._isReady = false;
		this._ready = new Signal([Object]);
		this._isLoaded = false;
		this._loaded = new Signal([Object]);
		this._docDomContentLoaded = new NativeSignal(this._doc, "DOMContentLoaded");
		this._docDomContentLoaded.add(this._handleReady, this);
		this._docReadyStateChanged = new NativeSignal(this._doc, "readystatechange");
		this._docReadyStateChanged.add(this._handleReady, this);
		this._winLoaded = new NativeSignal(this._win, "load");
		this._winLoaded.add(this._handleLoaded, this);
		if (this._doc.readyState === "complete") {
			setTimeout(Shaolin.bind(this._resolveReadyAndLoadedDispatch, this), 1); //delay execution so listeners can be added
		} else {
			if (this._doc.createEventObject && this._root.doScroll) {
				try {
					top = !this._win.frameElement;
				} catch (e) {
				}
				if (top) {
					this._bPoll = Shaolin.bind(this._poll, this);
					setTimeout(this._bPoll, 1);
				}
			}
		}
	};
	Constr.prototype = (function (p) {
		p._win = undefined;
		p._doc = undefined;
		p._root = undefined;
		p._isReady = undefined;
		p._ready = undefined;
		p._isLoaded = undefined;
		p._loaded = undefined;
		p._docDomContentLoaded = undefined;
		p._docReadyStateChanged = undefined;
		p._winLoaded = undefined;
		p._bPoll = undefined;
		p._poll = function () {
			try {
				this._root.doScroll("left");
			} catch (e) {
				setTimeout(this._bPoll, 50);
				return;
			}
			if (!this._isReady) {
				this._handleReady();
			}
		};
		p._resolveReadyDispatch = function () {
			if (!this._isReady) {
				this._isReady = true;
				this._docDomContentLoaded.remove(this._handleReady, this);
				this._docReadyStateChanged.remove(this._handleReady, this);
				this._ready.dispatch([this._win]);
			}
		};
		p._resolveReadyAndLoadedDispatch = function () {
			this._resolveReadyDispatch();
			if (!this._isLoaded) {
				this._isLoaded = true;
				this._winLoaded.remove(this._handleLoaded, this);
				this._loaded.dispatch([this._win]);
			}
		};
		p._handleReady = function (evt) {
			if (evt) {
				if (evt.type === "readystatechange" && this._doc.readyState !== "complete") {
					return;
				}
			}
			this._resolveReadyDispatch();
		};
		p._handleLoaded = function (evt) {
			this._resolveReadyAndLoadedDispatch();
		};
		/**
		* @exports p.getIsReady as Shaolin.Utils.DOMReady#getIsReady
		*/
		p.getIsReady = function () {
			return this._isReady;
		};
		/**
		* @exports p.getReady as Shaolin.Utils.DOMReady#getReady
		*/
		p.getReady = function () {
			return this._ready;
		};
		/**
		* @exports p.getIsLoaded as Shaolin.Utils.DOMReady#getIsLoaded
		*/
		p.getIsLoaded = function () {
			return this._isLoaded;
		};
		/**
		* @exports p.getLoaded as Shaolin.Utils.DOMReady#getLoaded
		*/
		p.getLoaded = function () {
			return this._loaded;
		};
		return p;
	}(Constr.prototype));
	return Constr;
}());