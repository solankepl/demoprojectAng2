//#include shaolin/Shaolin.js
//#include shaolin/signals/Signal.js

Shaolin.provide("Shaolin.Utils");

/**
* Defines a timer.
* @param {Number} tick The time in milliseconds representing one tick/cycle of the timer.
* @param {Number} repeat The number of ticks/cycles the timer will run before finishing.
* @class Defines a timer.
* @requires Shaolin
* @requires Shaolin.Signals.Signal
* @example
* var timer = new Shaolin.Utils.Timer(1000, 3);
*/
Shaolin.Utils.Timer = (function () {
	var Constr,
		Signal = Shaolin.Signals.Signal;
	/** @exports Constr as Shaolin.Utils.Timer */
	Constr = function (tick, repeat) {
		this._tick = tick;
		this._repeat = (!isNaN(repeat)) ? repeat : NaN;
		this._isRunning = false;
		this._elapsed = 0;
		this._bHandleTick = Shaolin.bind(this._handleTick, this);
		this._ticked = new Signal([Object]);
		this._completed = new Signal([Object]);
	};
	Constr.prototype = (function (p) {
		p._tick = undefined;
		p._repeat = undefined;
		p._isRunning = undefined;
		p._elapsed = undefined;
		p._bHandleTick = undefined;
		p._ticked = undefined;
		p._completed = undefined;
		p._timerID = undefined;
		p._handleTick = function () {
			this._elapsed += 1;
			this._ticked.dispatch([this]);
			if (!isNaN(this._repeat) && this._elapsed >= this._repeat) {
				this.stop();
				this._completed.dispatch([this]);
			}
		};
		/**
		* Returns a boolean value denoting if the timer is currently running
		* @returns {Boolean} Boolean value denoting if the timer is currently running.
		* @exports p.getIsRunning as Shaolin.Utils.Timer#getIsRunning
		* @example
		* var timer = new Shaolin.Utils.Timer(1000, 3);
		* alert(timer.getIsRunning()); //false
		* timer.start();
		* alert(timer.getIsRunning()); //true
		*/
		p.getIsRunning = function () {
			return this._isRunning;
		};
		/**
		* Returns the current elapsed count (number of ticks/cycles completed) of the timer.
		* @returns {Number} The current elapsed count of the timer.
		* @exports p.getElapsedCount as Shaolin.Utils.Timer#getElapsedCount
		* @example
		* var timer = new Shaolin.Utils.Timer(1000, 3);
		* alert(timer.getElapsedCount()); //0
		*/
		p.getElapsedCount = function () {
			return this._elapsed;
		};
		/**
		* Returns the number of ticks/cycles the timer will run before finishing.
		* @returns {Number} The number of ticks/cycles the timer will run before finishing.
		* @exports p.getRepeatCount as Shaolin.Utils.Timer#getRepeatCount
		* @example
		* var timer = new Shaolin.Utils.Timer(1000, 3);
		* alert(timer.getRepeatCount()); //3
		*/
		p.getRepeatCount = function () {
			return this._repeat;
		};
		/**
		* Returns the time in milliseconds representing one tick/cycle of the timer.
		* @returns {Number} The time in milliseconds representing one tick/cycle of the timer.
		* @exports p.getTick as Shaolin.Utils.Timer#getTick
		* @example
		* var timer = new Shaolin.Utils.Timer(1000, 3);
		* alert(timer.getTick()); //1000
		*/
		p.getTick = function () {
			return this._tick;
		};
		/**
		* Returns the Signal fired each time the timer finishes a tick/cycle while running.
		* @returns {Shaolin.Signals.Signal}
		* @exports p.getTicked as Shaolin.Utils.Timer#getTicked
		* @example
		* var timer = new Shaolin.Utils.Timer(1000, 3);
		* timer.getTicked().add(handleTimerTicked);
		*/
		p.getTicked = function () {
			return this._ticked;
		};
		/**
		* Returns the Signal fired once the timer finishes all ticks/cycles and finishes running.
		* @returns {Shaolin.Signals.Signal}
		* @exports p.getCompleted as Shaolin.Utils.Timer#getCompleted
		* var timer = new Shaolin.Utils.Timer(1000, 3);
		* timer.getCompleted().add(handleTimerCompleted);
		*/
		p.getCompleted = function () {
			return this._completed;
		};
		/**
		* Starts the timer.
		* @exports p.start as Shaolin.Utils.Timer#start
		* @example
		* var timer = new Shaolin.Utils.Timer(1000, 3);
		* timer.start();
		*/
		p.start = function () {
			if (this._isRunning) {
				this.stop();
			}
			this._isRunning = true;
			this._elapsed = 0;
			if (this._repeat <= 0) {
				this._isRunning = false;
				this._completed.dispatch([this]);
			} else {
				this._timerID = setInterval(this._bHandleTick, this._tick);
			}
		};
		/**
		* Stops the timer.
		* @exports p.stop as Shaolin.Utils.Timer#stop
		* @example
		* var timer = new Shaolin.Utils.Timer(1000, 3);
		* timer.start();
		* timer.stop();
		*/
		p.stop = function () {
			clearInterval(this._timerID);
			this._isRunning = false;
		};
		return p;
	}(Constr.prototype));
	return Constr;
}());